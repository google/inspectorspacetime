/*

Inspector Spacetime
Copyright (c) 2016
DESCRIPTION

*/

//encapsulate the script in a function to avoid global variables
(function (thisObj) {

    //================ VARIABLES ======================
      var scriptName = 'Inspector Spacetime';
      var scriptVersion = '1.01';
      var thisComp, fr, inspectorFolder, stackPos, leftEdge, panelSize = [0, 0], dataSize = [0, 0], iconScale, textLeftEdge;
      var margin, timeScalePrev = 0, timeVal = [0,0], labelColor;
      var aboutTxt =  'Speed up the creation of animation specs for engineering while reducing miscommunication. One click duplicates the comp and generates keyframe data as text layers (for manual tweaking). All of this is built along side the comp for easy reference.' +
                      '\n\n' +
                      'Usage:\n' +
                      'Select pairs of keyframes and press the button. That\'s it. There are a couple of options too.\n\n' +
                      '• Specs: Check the boxes of the desired spec lines.\n' +
                      '• Position: This data can be communicated as coordinates or in DP. Set the density dropdown based on resolution of your comp.\n' +
                      '• Isolation Mode: Creates an adjustment layer below the selected layer to dims other layers. This allows layers to be hilighted while keeping things in context.' +
                      '\n\n\n' +
                      scriptName + ': v' + scriptVersion + '\n' +
                      'Developed by: Adam Plouff';


    // ================ FUNCTIONS =============
      function setComp () {
     	 	thisComp = app.project.activeItem;
     		if (!thisComp || !(thisComp instanceof CompItem)) {		// Make sure a comp is selected
     			alert("Gotta select a comp first");
     			return false;
     		}
     		workStart = thisComp.workAreaStart;
     		workEnd = workStart + thisComp.workAreaDuration;
     		fr = thisComp.frameRate;
        return true;
   	  }
      function setStartPoint(currentTime) {
        var markerName = 'Start Transition';
        for (var i = 1; i <= thisComp.layers.length; i++) {     // loop through all layers
          try {
            for (var j = 1; j <= thisComp.layer(i).property('Marker').numKeys; j++) {
              var currentMarker = thisComp.layer(i).property('Marker').keyValue(j);
              if (currentMarker.comment === markerName) {
                thisComp.layer(i).property('Marker').removeKey(j);
                thisComp.layer(i).selected = true;
              }
            }

          } catch (e) {}
          // alert(thisComp.layer(i).name);
        }
        // var currentTime = getPlayheadTime();
        var startMarker = new MarkerValue(markerName);
        thisComp.selectedLayers[0].property('Marker').setValueAtTime(currentTime, startMarker);
      }
      function getPlayheadTime() {
        return thisComp.time;
      }
      function round(value, opt_decimals) {
        try{
          var decimals = (opt_decimals !== undefined) ? opt_decimals : 4;       // default to 4 decimal places if nothing is specified
          return Number(Math.round(value+'e'+decimals)+'e-'+decimals);
        } catch (e) {
          return value;
        }
      }
      function createStaticShape(path, vertexArray, inTangentsArray, outTangentsArray, closed) {
      	var pathValue = path.value;
      		pathValue.vertices = vertexArray;
      		pathValue.inTangents = inTangentsArray;
      		pathValue.outTangents = outTangentsArray;
      		pathValue.closed = closed;
      	path.setValue(pathValue);
      }
      function timeConvert(timeVal) {
        switch (ddl_timing.selection.index) {
          case 0:
            return Math.floor(timeVal * 1000);
          case 1:
            return timeVal;
          case 2:
            return Math.floor(timeVal * thisComp.frameRate);
          default:
            return '---';
        }
      }
      function grabCompData() {           // depreciate
        setComp();
        timeScalePrev = ddl_timing.selection.index;

        //// define generic object
        var compData = {
          selectedProp: '',
          inPoint: thisComp.workAreaStart,
          outPoint: thisComp.workAreaStart + thisComp.workAreaDuration
        };

        //// if a property is selected
        if (thisComp.selectedProperties.length > 0) {
          for (var i = 0; i < thisComp.selectedProperties.length; i++) {    // loop through all selected props looking for keys
            var activeProp = thisComp.selectedProperties[i];
            if (activeProp.selectedKeys.length > 0 && activeProp.selectedKeys.length !== 2) {
              alert('Gotta select only 2 keys for this to work');
            } else if (activeProp.selectedKeys.length === 2) { // check if 2 keys selected
              compData.inPoint = activeProp.keyTime(1);
              compData.outPoint = activeProp.keyTime(2);
              timeVal = [compData.inPoint, compData.outPoint];
              compData.selectedProp = activeProp.name;
            }
          }
        }

        //// Set scriptUI to grabbed data
        et_startTime.text = timeConvert(compData.inPoint);
        et_endTime.text = timeConvert(compData.outPoint);
        et_name.text = compData.selectedProp;

        defaultInput();     // if no prop selected then default the header text
      }
      function createISTfolder() {
        var hasRedlineFolder = false;
        for (var i = 1; i <= app.project.numItems; i++) {     // loop through all project items
          if (app.project.item(i) instanceof FolderItem) {    // find folders
            if (app.project.item(i).name == scriptName) {     // check it's name
              hasRedlineFolder = true;
              inspectorFolder = app.project.item(i);            // set the inspectorFolder var to the found folder
            }
          }
        }
        if (!hasRedlineFolder) {      // if no redline folder is found create one
          inspectorFolder = app.project.items.addFolder(scriptName);
        }
      }
      function resizeComp(work_comp) {

        //// Skip all this if there's already a panel layer
        for (var i = 1; i <= work_comp.layers.length; i++) {
          if (thisComp.layers[i].comment === scriptName + '_panel') {
            return;
          }
        }

        var currentTime = getPlayheadTime();                // Get the current playhead time
        createISTfolder();                                // make a new

        thisComp = work_comp.duplicate();                 // dup comp
        thisComp.parentFolder = inspectorFolder;            // move new comp to redline folder
        thisComp.name = work_comp.name + '_Spec';      // rename duped comp
        thisComp.openInViewer();                          // open new comp

        var compSize = [thisComp.width, thisComp.height];

        //// initialize variables
        panelSize = [thisComp.height/3, thisComp.height];
        leftEdge = thisComp.width;

        //// Resize comp
        thisComp.width = leftEdge + panelSize[0];


        //// Create info backing
        try {
        	// Add Shape Layer "++Comp Info++", varName "compInfo";
        	var compInfo = thisComp.layers.addShape();
        		compInfo.name = 'Spec Panel 1';
            compInfo.comment = scriptName + '_panel';
        		compInfo.label = 0;
        		// compInfo.moveToEnd();
        		compInfo.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
        		compInfo.property("ADBE Root Vectors Group").property(1).name = "Rectangle 1";
        		compInfo.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Rect");
        		compInfo.property("ADBE Root Vectors Group").property(1).property(2).property(1).property("ADBE Vector Rect Size").setValue(panelSize);
        		compInfo.property("ADBE Root Vectors Group").property(1).property(2).property(1).property("ADBE Vector Rect Position").setValue( panelSize/2 );
        		compInfo.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Graphic - Stroke");
        		compInfo.property("ADBE Root Vectors Group").property(1).property(2).property(2).enabled = false;
        		compInfo.property("ADBE Root Vectors Group").property(1).property(2).property(2).property("ADBE Vector Stroke Width").setValue(6);
        		compInfo.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Graphic - Fill");
        		compInfo.property("ADBE Root Vectors Group").property(1).property(2).property(3).property("ADBE Vector Fill Color").setValue([0.01176470611244,0.66274511814117,0.95686274766922,1]);
            compInfo.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
            compInfo.property("ADBE Root Vectors Group").property(2).name = "Admin";
        		compInfo.property("ADBE Root Vectors Group").property(2).property(3).property("ADBE Vector Scale").setValue(panelSize);
            compInfo.property("ADBE Transform Group").property("ADBE Position").setValue([leftEdge, 0]);
        } catch(e) {
        	alert(e.toString() + "\nError on line: " + e.line.toString());
        }

        //// Set the transiton start marker
        // var markerName = 'Start Transition';
        // var startMarker = new MarkerValue('Start Transition');
        // compInfo.property('Marker').setValueAtTime(currentTime, startMarker);
        // thisComp.time = currentTime;

        //// update positioning variables
        margin = Math.floor(panelSize[0] / 18);
        panelSize -= margin*2;
        leftEdge += margin;
        stackPos = margin;
      }
      function buildTxtHeader(activeProp) {
        var textBoxHeight = 100;
        // Create text header
        try {
        // Working with comp "Work_Redline", varName "workredline_comp";
          // var headTxt = thisComp.layers.addBoxText([dataSize[0], textBoxHeight], et_name.text);     // gets value from edittext
          var headTxt = thisComp.layers.addBoxText([dataSize[0], textBoxHeight], activeProp.obj.name);         // gets value from input property
              headTxt.comment = scriptName + '_data';
              headTxt.label = labelColor;
            var headTxt_TextProp = headTxt.property("ADBE Text Properties").property("ADBE Text Document");
            var headTxt_TextDocument = headTxt_TextProp.value;
              headTxt_TextDocument.font = "RobotoMono-Italic";
              headTxt_TextDocument.fontSize = Math.floor(dataSize[0] / 15);
              headTxt_TextDocument.applyFill = true;
              headTxt_TextDocument.fillColor = [1,1,1];
              headTxt_TextDocument.applyStroke = false;
              headTxt_TextDocument.justification = ParagraphJustification.LEFT_JUSTIFY;
              headTxt_TextDocument.tracking = -5;
              if (parseFloat(app.version) >= 13.2 ) {
                headTxt_TextDocument.verticalScale = 1;
                headTxt_TextDocument.horizontalScale = 1;
                headTxt_TextDocument.baselineShift = 0;
                headTxt_TextDocument.tsume = 0;
              }
              headTxt_TextProp.setValue(headTxt_TextDocument);
            headTxt.property("ADBE Transform Group").property("ADBE Position").setValue([leftEdge, stackPos, 0]);
            headTxt.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([-dataSize[0]/2, -textBoxHeight/2, 0]);

            //// update positioning variables
            stackPos += Math.round(headTxt.sourceRectAtTime(0, false).height) + margin;

        } catch(e) {
          alert(e.toString() + "\nError on line: " + e.line.toString());
        }
      }
      function builtTRT(time) {
        // Create text header
        try {
          //// build text
          var dynText = thisComp.layers.addText("Offset");
              dynText.comment = scriptName + '_data';
              dynText.label = labelColor;
          var dynText_TextProp = dynText.property("ADBE Text Properties").property("ADBE Text Document");
          var dynText_TextDocument = dynText_TextProp.value;
            dynText_TextDocument.font = "RobotoMono-Regular";
            dynText_TextDocument.fontSize = Math.floor(dataSize[0] / 15);
            dynText_TextDocument.applyFill = true;
            dynText_TextDocument.fillColor = [1,1,1];
            dynText_TextDocument.applyStroke = false;
            dynText_TextDocument.justification = ParagraphJustification.LEFT_JUSTIFY;
            dynText_TextDocument.tracking = -5;
            if (parseFloat(app.version) >= 13.2 ) {
              dynText_TextDocument.verticalScale = 1;
              dynText_TextDocument.horizontalScale = 1;
              dynText_TextDocument.baselineShift = 0;
              dynText_TextDocument.tsume = 0;
            }
            dynText_TextProp.setValue(dynText_TextDocument);
            dynText_TextProp.setValue('Total Duration: '+ Math.round(time * 1000) + 'ms');

            dynText.property("ADBE Transform Group").property("ADBE Position").setValue([leftEdge, stackPos, 0]);
            dynText.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([0, -stackPos, 0]);

            //// update positioning variables
            stackPos += Math.round(dynText.sourceRectAtTime(0, false).height) + margin * 2;

        } catch(e) {
          alert(e.toString() + "\nError on line: " + e.line.toString());
        }
      }
      function getPanelSize() {
        for(var i = 1; i <= thisComp.layers.length; i++) {
          if (thisComp.layer(i).comment == scriptName + '_panel') {
            panelSize = thisComp.layer(i).property("ADBE Root Vectors Group").property(2).property(3).property("ADBE Vector Scale").value;
            margin = Math.floor(panelSize[0] / 18)
            leftEdge = thisComp.layer(i)("ADBE Transform Group")("ADBE Position").value[0] + margin;
            stackPos = margin;
            dataSize = [panelSize[0] - margin*2, panelSize[1] - margin*2];
            iconScale = dataSize[0] / 8;
          }
        }
      }
      //// draw icon
      function valTiming(activeProp, firstKeyTime) {
        try {

        //// offset icon
        var iconoffset = thisComp.layers.addShape();
      		iconoffset.name = "Icon_Offset";
          iconoffset.comment = scriptName + '_data';
          iconoffset.label = labelColor;
      		iconoffset.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
      		iconoffset.property("ADBE Root Vectors Group").property(1).name = "Rectangle 1";
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Rect");
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).property(1).property("ADBE Vector Rect Size").setValue([50,10]);
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).property(1).property("ADBE Vector Rect Position").setValue([0,-20]);
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Rect");
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).property(2).property("ADBE Vector Rect Size").setValue([40,10]);
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).property(2).property("ADBE Vector Rect Position").setValue([5,0]);
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Rect");
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).property(3).property("ADBE Vector Rect Size").setValue([30,10]);
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).property(3).property("ADBE Vector Rect Position").setValue([10,20]);
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Graphic - Fill");
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).property(4).property("ADBE Vector Fill Color").setValue([1,1,1,1]);

          //// Transforms
          iconoffset.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([-25, -25, 0]);
          iconoffset.property("ADBE Transform Group").property("ADBE Position").setValue([leftEdge, stackPos, 0]);
          iconoffset.property("ADBE Transform Group").property("ADBE Scale").setValue([iconScale, iconScale]);

          //// update left edge
          textLeftEdge = leftEdge + Math.round(iconoffset.sourceRectAtTime(0, false).width) * (iconScale/100) + margin/2;

        //// build text
        var dynText = thisComp.layers.addText("Offset");
            dynText.comment = scriptName + '_data';
            dynText.label = labelColor;
        var dynText_TextProp = dynText.property("ADBE Text Properties").property("ADBE Text Document");
        var dynText_TextDocument = dynText_TextProp.value;
          dynText_TextDocument.font = "RobotoMono-Regular";
          dynText_TextDocument.fontSize = Math.floor(dataSize[0] / 15);
          dynText_TextDocument.applyFill = true;
          dynText_TextDocument.fillColor = [1,1,1];
          dynText_TextDocument.applyStroke = false;
          dynText_TextDocument.justification = ParagraphJustification.LEFT_JUSTIFY;
          dynText_TextDocument.tracking = -5;
          if (parseFloat(app.version) >= 13.2 ) {
            dynText_TextDocument.verticalScale = 1;
            dynText_TextDocument.horizontalScale = 1;
            dynText_TextDocument.baselineShift = 0;
            dynText_TextDocument.tsume = 0;
          }
          dynText_TextProp.setValue(dynText_TextDocument);
          dynText_TextProp.setValue(Math.round((activeProp.startTime - firstKeyTime) * 1000) + 'ms');
          // dynText_TextProp.expression = "var startMarker = Math.round( ("+ activePropTime[0] +"-thisComp.layer('Spec Panel 1').marker.key('Start Transition').time) * 1000) + 'ms';startMarker";

            //// Transforms
            dynText.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([0, -dynText_TextDocument.fontSize*0.82, 0]);
            dynText.property("ADBE Transform Group").property("ADBE Position").setValue([textLeftEdge, stackPos, 0]);
          } catch(e) {
            alert(e.toString() + "\nError on line: " + e.line.toString());
          }

            //// update positioning variables
            // stackPos += Math.round(iconoffset.sourceRectAtTime(0, false).height) * (iconScale/100) + margin;

            //// update left edge
            textLeftEdge += Math.round(dynText.sourceRectAtTime(0, false).width) + margin * 1.5;

          //// duration icon
          try {
            var iconduration = thisComp.layers.addShape();
                iconduration.comment = scriptName + '_data';
                iconduration.label = labelColor;
              iconduration.name = "Icon_Duration";
              iconduration.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
              iconduration.property("ADBE Root Vectors Group").property(1).name = "Arm 2";
              iconduration.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Rect");
              iconduration.property("ADBE Root Vectors Group").property(1).property(2).property(1).property("ADBE Vector Rect Size").setValue([4,16]);
              iconduration.property("ADBE Root Vectors Group").property(1).property(2).property(1).property("ADBE Vector Rect Position").setValue([0,-7]);
              iconduration.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Graphic - Fill");
              iconduration.property("ADBE Root Vectors Group").property(1).property(2).property(2).property("ADBE Vector Fill Color").setValue([1,1,1,1]);
              iconduration.property("ADBE Root Vectors Group").property(1).property(3).property("ADBE Vector Rotation").setValue(130);
              iconduration.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
              iconduration.property("ADBE Root Vectors Group").property(2).name = "Ellipse 1";
              iconduration.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Shape - Rect");
              iconduration.property("ADBE Root Vectors Group").property(2).property(2).property(1).property("ADBE Vector Rect Size").setValue([4,18]);
              iconduration.property("ADBE Root Vectors Group").property(2).property(2).property(1).property("ADBE Vector Rect Position").setValue([0,-8]);
              iconduration.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Shape - Ellipse");
              iconduration.property("ADBE Root Vectors Group").property(2).property(2).property(2).property("ADBE Vector Shape Direction").setValue(2);
              iconduration.property("ADBE Root Vectors Group").property(2).property(2).property(2).property("ADBE Vector Ellipse Size").setValue([50,50]);
              iconduration.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Shape - Ellipse");
              iconduration.property("ADBE Root Vectors Group").property(2).property(2).property(3).property("ADBE Vector Shape Direction").setValue(3);
              iconduration.property("ADBE Root Vectors Group").property(2).property(2).property(3).property("ADBE Vector Ellipse Size").setValue([40,40]);
              iconduration.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Graphic - Stroke");
              iconduration.property("ADBE Root Vectors Group").property(2).property(2).property(4).enabled = false;
              iconduration.property("ADBE Root Vectors Group").property(2).property(2).property(4).property("ADBE Vector Stroke Width").setValue(6);
              iconduration.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Graphic - Fill");
              iconduration.property("ADBE Root Vectors Group").property(2).property(2).property(5).property("ADBE Vector Fill Color").setValue([1,1,1,1]);
              iconduration.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
              iconduration.property("ADBE Root Vectors Group").property(3).name = "Shading";
              iconduration.property("ADBE Root Vectors Group").property(3).property(2).addProperty("ADBE Vector Shape - Group");
              var icondurationPath = iconduration.property("ADBE Root Vectors Group").property(3).property(2).property(1).property("ADBE Vector Shape");
              var icondurationPath_shapeVertices = [[-0.25,-22.5],[-0.375,-22.25],[-0.375,0],[17.625,14.5],[18.125,-14.125]];
              var icondurationPath_shapeInTangets = [[0,0],[0,0],[0,0],[0,0],[10.2841644287109,12.2430572509766]];
              var icondurationPath_shapeOutTangets = [[0,0],[0,0],[0,0],[0,0],[-7.875,-9.375]];
              var icondurationPath_shapeClosed = true;
              createStaticShape(icondurationPath, icondurationPath_shapeVertices, icondurationPath_shapeInTangets, icondurationPath_shapeOutTangets, icondurationPath_shapeClosed);
              iconduration.property("ADBE Root Vectors Group").property(3).property(2).addProperty("ADBE Vector Graphic - Stroke");
              iconduration.property("ADBE Root Vectors Group").property(3).property(2).property(2).enabled = false;
              iconduration.property("ADBE Root Vectors Group").property(3).property(2).property(2).property("ADBE Vector Stroke Width").setValue(6);
              iconduration.property("ADBE Root Vectors Group").property(3).property(2).addProperty("ADBE Vector Graphic - Fill");
              iconduration.property("ADBE Root Vectors Group").property(3).property(2).property(3).property("ADBE Vector Fill Color").setValue([1,1,1,1]);
              iconduration.property("ADBE Root Vectors Group").property(3).property(2).property(3).property("ADBE Vector Fill Opacity").setValue(40);

              //// Transforms
              iconduration.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([-25, -25, 0]);
              iconduration.property("ADBE Transform Group").property("ADBE Position").setValue([textLeftEdge, stackPos, 0]);
              iconduration.property("ADBE Transform Group").property("ADBE Scale").setValue([iconScale, iconScale]);

            //// update left edge
            textLeftEdge += Math.round(iconduration.sourceRectAtTime(0, false).width) * (iconScale/100) + margin/2;

            //// Duration text
            var durDynText = thisComp.layers.addText("Duration");
                durDynText.comment = scriptName + '_data';
                durDynText.label = labelColor;
            var durDynText_TextProp = durDynText.property("ADBE Text Properties").property("ADBE Text Document");
            var durDynText_TextDocument = durDynText_TextProp.value;
              durDynText_TextDocument.font = "RobotoMono-Regular";
              durDynText_TextDocument.fontSize = Math.floor(dataSize[0] / 15);
              durDynText_TextDocument.applyFill = true;
              durDynText_TextDocument.fillColor = [1,1,1];
              durDynText_TextDocument.applyStroke = false;
              durDynText_TextDocument.justification = ParagraphJustification.LEFT_JUSTIFY;
              durDynText_TextDocument.tracking = -5;
              if (parseFloat(app.version) >= 13.2 ) {
                durDynText_TextDocument.verticalScale = 1;
                durDynText_TextDocument.horizontalScale = 1;
                durDynText_TextDocument.baselineShift = 0;
                durDynText_TextDocument.tsume = 0;
              }
              durDynText_TextProp.setValue(durDynText_TextDocument);
              durDynText_TextProp.setValue(Math.round( activeProp.duration*1000) + 'ms');

                //// Transforms
                durDynText.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([0, -durDynText_TextDocument.fontSize*0.82, 0]);
                durDynText.property("ADBE Transform Group").property("ADBE Position").setValue([textLeftEdge, stackPos, 0]);
              } catch(e) {
                alert(e.toString() + "\nError on line: " + e.line.toString());
              }

              //// update positioning variables
              stackPos += Math.round(iconduration.sourceRectAtTime(0, false).height) * (iconScale/100) + margin;

      }
      function valOffset(activePropTime) {
        try {

        //// build icon
        var iconoffset = thisComp.layers.addShape();
      		iconoffset.name = "Icon_Offset";
          iconoffset.comment = scriptName + '_data';
          iconoffset.label = labelColor;
      		iconoffset.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
      		iconoffset.property("ADBE Root Vectors Group").property(1).name = "Rectangle 1";
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Rect");
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).property(1).property("ADBE Vector Rect Size").setValue([50,10]);
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).property(1).property("ADBE Vector Rect Position").setValue([0,-20]);
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Rect");
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).property(2).property("ADBE Vector Rect Size").setValue([40,10]);
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).property(2).property("ADBE Vector Rect Position").setValue([5,0]);
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Rect");
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).property(3).property("ADBE Vector Rect Size").setValue([30,10]);
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).property(3).property("ADBE Vector Rect Position").setValue([10,20]);
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Graphic - Fill");
      		iconoffset.property("ADBE Root Vectors Group").property(1).property(2).property(4).property("ADBE Vector Fill Color").setValue([1,1,1,1]);

          //// Transforms
          iconoffset.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([-25, -25, 0]);
          iconoffset.property("ADBE Transform Group").property("ADBE Position").setValue([leftEdge, stackPos, 0]);
          iconoffset.property("ADBE Transform Group").property("ADBE Scale").setValue([iconScale, iconScale]);

          //// update left edge
          var textLeftEdge = leftEdge + Math.round(iconoffset.sourceRectAtTime(0, false).width) * (iconScale/100) + margin/2;

        //// build text
        var dynText = thisComp.layers.addText("Offset");
            dynText.comment = scriptName + '_data';
            dynText.label = labelColor;
        var dynText_TextProp = dynText.property("ADBE Text Properties").property("ADBE Text Document");
        var dynText_TextDocument = dynText_TextProp.value;
          dynText_TextDocument.font = "RobotoMono-Regular";
          dynText_TextDocument.fontSize = Math.floor(dataSize[0] / 15);
          dynText_TextDocument.applyFill = true;
          dynText_TextDocument.fillColor = [1,1,1];
          dynText_TextDocument.applyStroke = false;
          dynText_TextDocument.justification = ParagraphJustification.LEFT_JUSTIFY;
          dynText_TextDocument.tracking = -5;
          if (parseFloat(app.version) >= 13.2 ) {
            dynText_TextDocument.verticalScale = 1;
            dynText_TextDocument.horizontalScale = 1;
            dynText_TextDocument.baselineShift = 0;
            dynText_TextDocument.tsume = 0;
          }
          dynText_TextProp.setValue(dynText_TextDocument);
          dynText_TextProp.expression = "var startMarker = Math.round( ("+ activePropTime[0] +"-thisComp.layer('Spec Panel 1').marker.key('Start Transition').time) * 1000) + 'ms';startMarker";

            //// Transforms
            dynText.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([0, -dynText_TextDocument.fontSize*0.82, 0]);
            dynText.property("ADBE Transform Group").property("ADBE Position").setValue([textLeftEdge, stackPos, 0]);
          } catch(e) {
            alert(e.toString() + "\nError on line: " + e.line.toString());
          }

            //// update positioning variables
            stackPos += Math.round(iconoffset.sourceRectAtTime(0, false).height) * (iconScale/100) + margin;
      }
      function valDuration(activePropTime) {
        try {
          var iconduration = thisComp.layers.addShape();
              iconduration.comment = scriptName + '_data';
              iconduration.label = labelColor;
        		iconduration.name = "Icon_Duration";
        		iconduration.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
        		iconduration.property("ADBE Root Vectors Group").property(1).name = "Arm 2";
        		iconduration.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Rect");
        		iconduration.property("ADBE Root Vectors Group").property(1).property(2).property(1).property("ADBE Vector Rect Size").setValue([4,16]);
        		iconduration.property("ADBE Root Vectors Group").property(1).property(2).property(1).property("ADBE Vector Rect Position").setValue([0,-7]);
        		iconduration.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Graphic - Fill");
        		iconduration.property("ADBE Root Vectors Group").property(1).property(2).property(2).property("ADBE Vector Fill Color").setValue([1,1,1,1]);
        		iconduration.property("ADBE Root Vectors Group").property(1).property(3).property("ADBE Vector Rotation").setValue(130);
        		iconduration.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
        		iconduration.property("ADBE Root Vectors Group").property(2).name = "Ellipse 1";
        		iconduration.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Shape - Rect");
        		iconduration.property("ADBE Root Vectors Group").property(2).property(2).property(1).property("ADBE Vector Rect Size").setValue([4,18]);
        		iconduration.property("ADBE Root Vectors Group").property(2).property(2).property(1).property("ADBE Vector Rect Position").setValue([0,-8]);
        		iconduration.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Shape - Ellipse");
        		iconduration.property("ADBE Root Vectors Group").property(2).property(2).property(2).property("ADBE Vector Shape Direction").setValue(2);
        		iconduration.property("ADBE Root Vectors Group").property(2).property(2).property(2).property("ADBE Vector Ellipse Size").setValue([50,50]);
        		iconduration.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Shape - Ellipse");
        		iconduration.property("ADBE Root Vectors Group").property(2).property(2).property(3).property("ADBE Vector Shape Direction").setValue(3);
        		iconduration.property("ADBE Root Vectors Group").property(2).property(2).property(3).property("ADBE Vector Ellipse Size").setValue([40,40]);
        		iconduration.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Graphic - Stroke");
        		iconduration.property("ADBE Root Vectors Group").property(2).property(2).property(4).enabled = false;
        		iconduration.property("ADBE Root Vectors Group").property(2).property(2).property(4).property("ADBE Vector Stroke Width").setValue(6);
        		iconduration.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Graphic - Fill");
        		iconduration.property("ADBE Root Vectors Group").property(2).property(2).property(5).property("ADBE Vector Fill Color").setValue([1,1,1,1]);
        		iconduration.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
        		iconduration.property("ADBE Root Vectors Group").property(3).name = "Shading";
        		iconduration.property("ADBE Root Vectors Group").property(3).property(2).addProperty("ADBE Vector Shape - Group");
        		var icondurationPath = iconduration.property("ADBE Root Vectors Group").property(3).property(2).property(1).property("ADBE Vector Shape");
        		var icondurationPath_shapeVertices = [[-0.25,-22.5],[-0.375,-22.25],[-0.375,0],[17.625,14.5],[18.125,-14.125]];
        		var icondurationPath_shapeInTangets = [[0,0],[0,0],[0,0],[0,0],[10.2841644287109,12.2430572509766]];
        		var icondurationPath_shapeOutTangets = [[0,0],[0,0],[0,0],[0,0],[-7.875,-9.375]];
        		var icondurationPath_shapeClosed = true;
        		createStaticShape(icondurationPath, icondurationPath_shapeVertices, icondurationPath_shapeInTangets, icondurationPath_shapeOutTangets, icondurationPath_shapeClosed);
        		iconduration.property("ADBE Root Vectors Group").property(3).property(2).addProperty("ADBE Vector Graphic - Stroke");
        		iconduration.property("ADBE Root Vectors Group").property(3).property(2).property(2).enabled = false;
        		iconduration.property("ADBE Root Vectors Group").property(3).property(2).property(2).property("ADBE Vector Stroke Width").setValue(6);
        		iconduration.property("ADBE Root Vectors Group").property(3).property(2).addProperty("ADBE Vector Graphic - Fill");
        		iconduration.property("ADBE Root Vectors Group").property(3).property(2).property(3).property("ADBE Vector Fill Color").setValue([1,1,1,1]);
        		iconduration.property("ADBE Root Vectors Group").property(3).property(2).property(3).property("ADBE Vector Fill Opacity").setValue(40);

            //// Transforms
            iconduration.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([-25, -25, 0]);
            iconduration.property("ADBE Transform Group").property("ADBE Position").setValue([leftEdge, stackPos, 0]);
            iconduration.property("ADBE Transform Group").property("ADBE Scale").setValue([iconScale, iconScale]);

          //// update left edge
          var textLeftEdge = leftEdge + Math.round(iconduration.sourceRectAtTime(0, false).width) * (iconScale/100) + margin/2;

        var dynText = thisComp.layers.addText("Duration");
            dynText.comment = scriptName + '_data';
            dynText.label = labelColor;
        var dynText_TextProp = dynText.property("ADBE Text Properties").property("ADBE Text Document");
        var dynText_TextDocument = dynText_TextProp.value;
          dynText_TextDocument.font = "RobotoMono-Regular";
          dynText_TextDocument.fontSize = Math.floor(dataSize[0] / 15);
          dynText_TextDocument.applyFill = true;
          dynText_TextDocument.fillColor = [1,1,1];
          dynText_TextDocument.applyStroke = false;
          dynText_TextDocument.justification = ParagraphJustification.LEFT_JUSTIFY;
          dynText_TextDocument.tracking = -5;
          if (parseFloat(app.version) >= 13.2 ) {
            dynText_TextDocument.verticalScale = 1;
            dynText_TextDocument.horizontalScale = 1;
            dynText_TextDocument.baselineShift = 0;
            dynText_TextDocument.tsume = 0;
          }
          dynText_TextProp.setValue(dynText_TextDocument);
          dynText_TextProp.setValue(Math.round( (activePropTime[1] - activePropTime[0])*1000) + 'ms');

            //// Transforms
            dynText.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([0, -dynText_TextDocument.fontSize*0.82, 0]);
            dynText.property("ADBE Transform Group").property("ADBE Position").setValue([textLeftEdge, stackPos, 0]);
          } catch(e) {
            alert(e.toString() + "\nError on line: " + e.line.toString());
          }

            //// update positioning variables
            stackPos += Math.round(iconduration.sourceRectAtTime(0, false).height) * (iconScale/100) + margin;

      }
      function valPosition(activeProp) {
        var a = activeProp.startValue;
        var b = activeProp.endValue;

        var pixelMult = ddl_resolution.selection.index+1;
        var vectAngle = Math.atan2(b[1] - a[1], b[0] - a[0]) * (180 / Math.PI) + 90;
        var vectDist = Math.sqrt( Math.pow(b[0] - a[0], 2 ) + Math.pow(b[1] - a[1], 2) ) / pixelMult;


        try {
          //// draw icon
          var icon = thisComp.layers.addShape();
        		icon.name = "Icon_Position";
            icon.label = labelColor;
        		icon.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Group");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).name = "Rectangle 2";
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).addProperty("ADBE Vector Shape - Rect");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).property(1).property("ADBE Vector Rect Size").setValue([30,30]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).property(1).property("ADBE Vector Rect Position").setValue([-2,-2]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).addProperty("ADBE Vector Filter - Trim");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).property(2).property("ADBE Vector Trim End").setValue(38);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).property(2).property("ADBE Vector Trim Offset").setValue(-158);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).addProperty("ADBE Vector Graphic - Stroke");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).property(3).property("ADBE Vector Stroke Width").setValue(8);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).addProperty("ADBE Vector Graphic - Fill");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).property(4).enabled = false;
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).property(4).property("ADBE Vector Fill Color").setValue([1,1,1,1]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(3).property("ADBE Vector Rotation").setValue(45);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Group");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(2).name = "Rectangle 1";
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).addProperty("ADBE Vector Shape - Rect");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).property(1).property("ADBE Vector Rect Size").setValue([0,29]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).property(1).property("ADBE Vector Rect Position").setValue([0,-6]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).addProperty("ADBE Vector Shape - Rect");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).property(2).property("ADBE Vector Rect Size").setValue([10,10]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).property(2).property("ADBE Vector Rect Position").setValue([0,15]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).property(2).property("ADBE Vector Rect Roundness").setValue(127);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).addProperty("ADBE Vector Graphic - Stroke");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).property(3).property("ADBE Vector Stroke Width").setValue(8);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).addProperty("ADBE Vector Graphic - Fill");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).property(4).enabled = false;
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(2).property(2).property(4).property("ADBE Vector Fill Color").setValue([1,1,1,1]);
        		icon.property("ADBE Root Vectors Group").property(1).property(3).property("ADBE Vector Anchor").setValue([0,-1.52081489562988]);
        		icon.property("ADBE Root Vectors Group").property(1).property(3).property("ADBE Vector Position").setValue([0,-1.52081489562988]);
            icon.property("ADBE Root Vectors Group").property(1).property(3).property("ADBE Vector Rotation").setValue(vectAngle);
            icon.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
            icon.property("ADBE Root Vectors Group").property(2).name = "Bounds";
        		icon.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Shape - Ellipse");
        		icon.property("ADBE Root Vectors Group").property(2).property(2).property(1).property("ADBE Vector Ellipse Size").setValue([50,50]);


            //// Transforms
            icon.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([-25, -25, 0]);
            icon.property("ADBE Transform Group").property("ADBE Position").setValue([leftEdge, stackPos, 0]);
            icon.property("ADBE Transform Group").property("ADBE Scale").setValue([iconScale, iconScale]);

          //// update left edge
          var textLeftEdge = leftEdge + Math.round(icon.sourceRectAtTime(0, false).width) * (iconScale/100) + margin;


        //// draw text
        var dynText = thisComp.layers.addText("Position Easing");
            dynText.comment = scriptName + '_data';
            dynText.label = labelColor;
        var dynText_TextProp = dynText.property("ADBE Text Properties").property("ADBE Text Document");
        var dynText_TextDocument = dynText_TextProp.value;

          dynText_TextDocument.fontSize = Math.floor(dataSize[0] / 15);
          dynText_TextDocument.applyFill = true;
          dynText_TextDocument.fillColor = [1,1,1];
          dynText_TextDocument.applyStroke = false;
          dynText_TextDocument.justification = ParagraphJustification.LEFT_JUSTIFY;
          dynText_TextDocument.tracking = -5;
          if (parseFloat(app.version) >= 13.2 ) {
            dynText_TextDocument.verticalScale = 1;
            dynText_TextDocument.horizontalScale = 1;
            dynText_TextDocument.baselineShift = 0;
            dynText_TextDocument.tsume = 0;
          }


          //// distance vs abs position values
          if (rad_pos.children[1].value) {          // Distance selected
            dynText_TextDocument.font = "RobotoMono-Regular";
            dynText_TextProp.setValue(dynText_TextDocument);
            dynText_TextProp.setValue(Math.round(vectDist) + 'dp');
          } else {
            dynText_TextDocument.fontSize = Math.floor(dataSize[0] / 20);
            dynText_TextDocument.font = "RobotoMono-Medium";
            dynText_TextProp.setValue(dynText_TextDocument);
            dynText_TextProp.setValue('[' + Math.round(a[0]) + ', ' + Math.round(a[1]) + '] ››› [' + Math.round(b[0]) + ', ' + Math.round(b[1]) + ']');
          }


            //// Transforms
            dynText.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([0, -dynText_TextDocument.fontSize*0.82, 0]);
            dynText.property("ADBE Transform Group").property("ADBE Position").setValue([textLeftEdge, stackPos, 0]);

          } catch(e) {
            alert(e.toString() + "\nError on line: " + e.line.toString());
          }

          //// update positioning variables
          stackPos += Math.round(icon.sourceRectAtTime(0, false).height) * (iconScale/100) + margin;

          Math.degrees = function(radians) {
            return radians * 180 / Math.PI;
          };

      }
      function valOpacity(activeProp) {
        var a = activeProp.startValue;
        var b = activeProp.endValue;
        try {
          //// draw icon
          var icon = thisComp.layers.addShape();
        		icon.name = "Icon_Opacity";
            icon.label = labelColor;
        		icon.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
        		icon.property("ADBE Root Vectors Group").property(1).name = "Group";
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Rect");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).name = "Horiz 4";
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property("ADBE Vector Rect Size").setValue([15,4]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property("ADBE Vector Rect Position").setValue([8,-14]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Rect");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(2).name = "Horiz 5";
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(2).property("ADBE Vector Rect Size").setValue([20,4]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(2).property("ADBE Vector Rect Position").setValue([10,-7]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Rect");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(3).name = "Horiz 1";
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(3).property("ADBE Vector Rect Size").setValue([22,4]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(3).property("ADBE Vector Rect Position").setValue([10,0]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Rect");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(4).name = "Horiz 2";
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(4).property("ADBE Vector Rect Size").setValue([22,4]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(4).property("ADBE Vector Rect Position").setValue([10,7]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Rect");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(5).name = "Horiz 3";
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(5).property("ADBE Vector Rect Size").setValue([15,4]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(5).property("ADBE Vector Rect Position").setValue([8,14]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Rect");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(6).property("ADBE Vector Rect Size").setValue([4,43]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Ellipse");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(7).property("ADBE Vector Shape Direction").setValue(2);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(7).property("ADBE Vector Ellipse Size").setValue([50,50]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Ellipse");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(8).property("ADBE Vector Shape Direction").setValue(3);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(8).property("ADBE Vector Ellipse Size").setValue([40,40]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Graphic - Fill");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(9).property("ADBE Vector Fill Color").setValue([1,1,1,1]);

            //// Transforms
            icon.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([-25, -25, 0]);
            icon.property("ADBE Transform Group").property("ADBE Position").setValue([leftEdge, stackPos, 0]);
            icon.property("ADBE Transform Group").property("ADBE Scale").setValue([iconScale, iconScale]);

          //// update left edge
          var textLeftEdge = leftEdge + Math.round(icon.sourceRectAtTime(0, false).width) * (iconScale/100) + margin/2;


        //// draw text
        var dynText = thisComp.layers.addText("Opacity");
            dynText.comment = scriptName + '_data';
            dynText.label = labelColor;
        var dynText_TextProp = dynText.property("ADBE Text Properties").property("ADBE Text Document");
        var dynText_TextDocument = dynText_TextProp.value;
          dynText_TextDocument.font = "RobotoMono-Regular";
          dynText_TextDocument.fontSize = Math.floor(dataSize[0] / 15);
          dynText_TextDocument.applyFill = true;
          dynText_TextDocument.fillColor = [1,1,1];
          dynText_TextDocument.applyStroke = false;
          dynText_TextDocument.justification = ParagraphJustification.LEFT_JUSTIFY;
          dynText_TextDocument.tracking = -5;
          if (parseFloat(app.version) >= 13.2 ) {
            dynText_TextDocument.verticalScale = 1;
            dynText_TextDocument.horizontalScale = 1;
            dynText_TextDocument.baselineShift = 0;
            dynText_TextDocument.tsume = 0;
          }
          dynText_TextProp.setValue(dynText_TextDocument);
          dynText_TextProp.setValue(round(a, 2) + '% ››› ' + round(b, 2) + '%');

            //// Transforms
            dynText.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([0, -dynText_TextDocument.fontSize*0.82, 0]);
            dynText.property("ADBE Transform Group").property("ADBE Position").setValue([textLeftEdge, stackPos, 0]);

          } catch(e) {
            alert(e.toString() + "\nError on line: " + e.line.toString());
          }

            //// update positioning variables
            stackPos += Math.round(icon.sourceRectAtTime(0, false).height) * (iconScale/100) + margin;

      }
      function valRotation(activeProp) {
        var a = activeProp.startValue;
        var b = activeProp.endValue;
        try {
          //// draw icon
          var rotDir = ( a > b ) ? 1 : -1;
          var icon = thisComp.layers.addShape();
        		icon.name = "Icon_Rotation";
            icon.label = labelColor;
        		icon.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
        		icon.property("ADBE Root Vectors Group").property(1).name = "Shape 1";
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Group");
        		var iconPath = icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property("ADBE Vector Shape");
        		var iconPath_shapeVertices = [[2.45626831054688,-20.8176574707031],[2.45626831054688,-29.5534362792969],[-10.4909057617188,-16.6062622070312],[2.45626831054688,-3.94364929199219],[2.45626831054688,-15.0696716308594],[16.6839294433594,1.74742126464844],[2.45626831054688,18.5645294189453],[2.45626831054688,24.3125],[22.375,1.74742126464844]];
        		var iconPath_shapeInTangets = [[11.2398529052734,1.39431762695312],[0,0],[0,0],[0,0],[0,0],[0,-8.45123291015625],[8.08131408691406,-1.36585998535156],[0,0],[0,11.6097869873047]];
        		var iconPath_shapeOutTangets = [[0,0],[0,0],[0,0],[0,0],[8.08131408691406,1.3658447265625],[0,8.45123291015625],[0,0],[11.2398529052734,-1.39430236816406],[0,-11.6097717285156]];
        		var iconPath_shapeClosed = true;
        		createStaticShape(iconPath, iconPath_shapeVertices, iconPath_shapeInTangets, iconPath_shapeOutTangets, iconPath_shapeClosed);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Group");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(2).name = "Path 4";
        		var iconPath = icon.property("ADBE Root Vectors Group").property(1).property(2).property(2).property("ADBE Vector Shape");
        		var iconPath_shapeVertices = [[-14.3323822021484,19.7311859130859],[-3.23480224609375,24.3125],[-3.23480224609375,18.5360717773438],[-10.2348022460938,15.6051635742188]];
        		var iconPath_shapeInTangets = [[0,0],[-3.95529174804688,-0.48373413085938],[0,0],[2.13414001464844,1.53659057617188]];
        		var iconPath_shapeOutTangets = [[3.30082702636719,2.56098937988281],[0,0],[-2.47561645507812,-0.42683410644531],[0,0]];
        		var iconPath_shapeClosed = true;
        		createStaticShape(iconPath, iconPath_shapeVertices, iconPath_shapeInTangets, iconPath_shapeOutTangets, iconPath_shapeClosed);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Group");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(3).name = "Path 3";
        		var iconPath = icon.property("ADBE Root Vectors Group").property(1).property(2).property(3).property("ADBE Vector Shape");
        		var iconPath_shapeVertices = [[-17.2063598632812,4.59295654296875],[-22.954345703125,4.59295654296875],[-18.3445739746094,15.6620788574219],[-14.3323822021484,11.6214294433594]];
        		var iconPath_shapeInTangets = [[0.39837646484375,2.50407409667969],[0,0],[-2.56098937988281,-3.30081176757812],[0,0]];
        		var iconPath_shapeOutTangets = [[0,0],[0.48374938964844,3.95529174804688],[0,0],[-1.47967529296875,-2.1341552734375]];
        		var iconPath_shapeClosed = true;
        		createStaticShape(iconPath, iconPath_shapeVertices, iconPath_shapeInTangets, iconPath_shapeOutTangets, iconPath_shapeClosed);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Group");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(4).name = "Path 2";
        		var iconPath = icon.property("ADBE Root Vectors Group").property(1).property(2).property(4).property("ADBE Vector Shape");
        		var iconPath_shapeVertices = [[-14.3039245605469,-8.12657165527344],[-18.3161163330078,-12.167236328125],[-22.954345703125,-1.09811401367188],[-17.2063598632812,-1.09811401367188]];
        		var iconPath_shapeInTangets = [[-1.50813293457031,2.13414001464844],[0,0],[0.48374938964844,-3.95529174804688],[0,0]];
        		var iconPath_shapeOutTangets = [[0,0],[-2.56098937988281,3.30082702636719],[0,0],[0.39837646484375,-2.47560119628906]];
        		var iconPath_shapeClosed = true;
        		createStaticShape(iconPath, iconPath_shapeVertices, iconPath_shapeInTangets, iconPath_shapeOutTangets, iconPath_shapeClosed);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Graphic - Stroke");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(5).enabled = false;
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Graphic - Fill");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(6).property("ADBE Vector Fill Color").setValue([1,1,1,1]);
        		icon.property("ADBE Root Vectors Group").property(1).property(3).property("ADBE Vector Scale").setValue([100 * rotDir,100]);


            //// Transforms
            icon.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([-25, -25, 0]);
            icon.property("ADBE Transform Group").property("ADBE Position").setValue([leftEdge, stackPos, 0]);
            icon.property("ADBE Transform Group").property("ADBE Scale").setValue([iconScale, iconScale]);


          //// update left edge
          var textLeftEdge = leftEdge + Math.round(icon.sourceRectAtTime(0, false).width) * (iconScale/100) + margin/2;


        //// draw text
        var dynText = thisComp.layers.addText("Rotataion");
            dynText.comment = scriptName + '_data';
            dynText.label = labelColor;
        var dynText_TextProp = dynText.property("ADBE Text Properties").property("ADBE Text Document");
        var dynText_TextDocument = dynText_TextProp.value;
          dynText_TextDocument.font = "RobotoMono-Regular";
          dynText_TextDocument.fontSize = Math.floor(dataSize[0] / 15);
          dynText_TextDocument.applyFill = true;
          dynText_TextDocument.fillColor = [1,1,1];
          dynText_TextDocument.applyStroke = false;
          dynText_TextDocument.justification = ParagraphJustification.LEFT_JUSTIFY;
          dynText_TextDocument.tracking = -5;
          if (parseFloat(app.version) >= 13.2 ) {
            dynText_TextDocument.verticalScale = 1;
            dynText_TextDocument.horizontalScale = 1;
            dynText_TextDocument.baselineShift = 0;
            dynText_TextDocument.tsume = 0;
          }
          dynText_TextProp.setValue(dynText_TextDocument);
          dynText_TextProp.setValue(round(a, 2) + '° ››› ' + round(b, 2) + '°');

            //// Transforms
            dynText.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([0, -dynText_TextDocument.fontSize*0.82, 0]);
            dynText.property("ADBE Transform Group").property("ADBE Position").setValue([textLeftEdge, stackPos, 0]);

          } catch(e) {
            alert(e.toString() + "\nError on line: " + e.line.toString());
          }

            //// update positioning variables
            stackPos += Math.round(icon.sourceRectAtTime(0, false).height) * (iconScale/100) + margin;

      }
      function valScale(activeProp) {
        var a = activeProp.startValue;
        var b = activeProp.endValue;

        var scaleUp = ( (a[0] + a[1])/2 < (b[0] + b[1])/2 ) ? true : false;


        try {
          //// draw icon
          var icon = thisComp.layers.addShape();
            icon.name = "Icon_Position";
            icon.label = labelColor;
            icon.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
        		icon.property("ADBE Root Vectors Group").property(1).name = "ScaleDown";
            icon.property("ADBE Root Vectors Group").property(1).enabled = !scaleUp;
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Group");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).name = "Arrow";
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).addProperty("ADBE Vector Shape - Rect");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).property(1).property("ADBE Vector Rect Size").setValue([47,47]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).property(1).property("ADBE Vector Rect Position").setValue([-34,34]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).addProperty("ADBE Vector Filter - Trim");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).property(2).property("ADBE Vector Trim End").setValue(10);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property(2).property(2).property("ADBE Vector Trim Offset").setValue(-18);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Group");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(2).property("ADBE Vector Shape Direction").setValue(2);
        		var iconPath = icon.property("ADBE Root Vectors Group").property(1).property(2).property(2).property("ADBE Vector Shape");
        		var iconPath_shapeVertices = [[-11.875,-11.875],[-25,-25]];
        		var iconPath_shapeInTangets = [[0,0],[0,0]];
        		var iconPath_shapeOutTangets = [[0,0],[0,0]];
        		var iconPath_shapeClosed = true;
        		createStaticShape(iconPath, iconPath_shapeVertices, iconPath_shapeInTangets, iconPath_shapeOutTangets, iconPath_shapeClosed);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Graphic - Fill");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(3).enabled = false;
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Filter - Repeater");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(4).property("ADBE Vector Repeater Copies").setValue(4);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(4).property(4).property("ADBE Vector Repeater Rotation").setValue(90);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Rect");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(5).property("ADBE Vector Rect Size").setValue([11,11]);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Graphic - Stroke");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(6).property("ADBE Vector Stroke Width").setValue(5);
        		icon.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");

            icon.property("ADBE Root Vectors Group").property(2).name = "ScaleUp";
            icon.property("ADBE Root Vectors Group").property(2).enabled = scaleUp;
        		icon.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Group");
        		icon.property("ADBE Root Vectors Group").property(2).property(2).property(1).name = "Arrow";
        		icon.property("ADBE Root Vectors Group").property(2).property(2).property(1).property(2).addProperty("ADBE Vector Shape - Rect");
        		icon.property("ADBE Root Vectors Group").property(2).property(2).property(1).property(2).property(1).property("ADBE Vector Rect Size").setValue([47,47]);
        		icon.property("ADBE Root Vectors Group").property(2).property(2).property(1).property(2).addProperty("ADBE Vector Filter - Trim");
        		icon.property("ADBE Root Vectors Group").property(2).property(2).property(1).property(2).property(2).property("ADBE Vector Trim End").setValue(13.3);
        		icon.property("ADBE Root Vectors Group").property(2).property(2).property(1).property(2).property(2).property("ADBE Vector Trim Offset").setValue(-23.9);
        		icon.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Shape - Group");
        		icon.property("ADBE Root Vectors Group").property(2).property(2).property(2).property("ADBE Vector Shape Direction").setValue(2);
        		var iconPath = icon.property("ADBE Root Vectors Group").property(2).property(2).property(2).property("ADBE Vector Shape");
        		var iconPath_shapeVertices = [[-11.25,-11.25],[-25,-25]];
        		var iconPath_shapeInTangets = [[0,0],[0,0]];
        		var iconPath_shapeOutTangets = [[0,0],[0,0]];
        		var iconPath_shapeClosed = true;
        		createStaticShape(iconPath, iconPath_shapeVertices, iconPath_shapeInTangets, iconPath_shapeOutTangets, iconPath_shapeClosed);
        		icon.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Graphic - Fill");
        		icon.property("ADBE Root Vectors Group").property(2).property(2).property(3).enabled = false;
        		icon.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Filter - Repeater");
        		icon.property("ADBE Root Vectors Group").property(2).property(2).property(4).property("ADBE Vector Repeater Copies").setValue(4);
        		icon.property("ADBE Root Vectors Group").property(2).property(2).property(4).property(4).property("ADBE Vector Repeater Rotation").setValue(90);
        		icon.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Shape - Rect");
        		icon.property("ADBE Root Vectors Group").property(2).property(2).property(5).property("ADBE Vector Rect Size").setValue([17,17]);
        		icon.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Graphic - Stroke");
        		icon.property("ADBE Root Vectors Group").property(2).property(2).property(6).property("ADBE Vector Stroke Width").setValue(5);



            //// Transforms
            icon.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([-25, -25, 0]);
            icon.property("ADBE Transform Group").property("ADBE Position").setValue([leftEdge, stackPos, 0]);
            icon.property("ADBE Transform Group").property("ADBE Scale").setValue([iconScale, iconScale]);

          //// update left edge
          var textLeftEdge = leftEdge + Math.round(icon.sourceRectAtTime(0, false).width) * (iconScale/100) + margin / 2;


        //// draw text
        var dynText = thisComp.layers.addText("Property");
            dynText.comment = scriptName + '_data';
            dynText.label = labelColor;
        var dynText_TextProp = dynText.property("ADBE Text Properties").property("ADBE Text Document");
        var dynText_TextDocument = dynText_TextProp.value;

          dynText_TextDocument.fontSize = Math.floor(dataSize[0] / 15);
          dynText_TextDocument.applyFill = true;
          dynText_TextDocument.fillColor = [1,1,1];
          dynText_TextDocument.applyStroke = false;
          dynText_TextDocument.justification = ParagraphJustification.LEFT_JUSTIFY;
          dynText_TextDocument.tracking = -5;
          if (parseFloat(app.version) >= 13.2 ) {
            dynText_TextDocument.verticalScale = 1;
            dynText_TextDocument.horizontalScale = 1;
            dynText_TextDocument.baselineShift = 0;
            dynText_TextDocument.tsume = 0;
          }

          var single = (a[0] == a[1] && b[0] == b[1]) ? true : false;
          var xFactor = round(Math.round(a[0]) / Math.round(b[0]), 2);
          if (a[0])
          if (isNaN(xFactor)) { xFactor = 0; }  // scale to zero

          //// Factor vs Percentage
          // if (rad_scale.children[1].value) {          // Percentage selected
            var arrow = (scaleUp) ? '↑' : '↓';

            if (single) {     // check if the scale values are uniform
              dynText_TextDocument.font = "RobotoMono-Regular";
              dynText_TextProp.setValue(dynText_TextDocument);
              dynText_TextProp.setValue(a[0] + '% ››› ' + b[0] + '%');  // print single vals
            } else {
              dynText_TextDocument.fontSize = Math.floor(dataSize[0] / 20);
              dynText_TextDocument.font = "RobotoMono-Medium";
              dynText_TextProp.setValue(dynText_TextDocument);
              dynText_TextProp.setValue('[' + round(a[0], 2) + ', ' + round(a[1], 2) + ']% ››› [' + round(b[0], 2) + ', ' + round(b[1], 2) + ']%');   // print arrays
            }
          // } else {

            // if (single) {     // check if the scale values are uniform
            //   dynText_TextDocument.font = "RobotoMono-Regular";
            //   dynText_TextProp.setValue(dynText_TextDocument);
            //   dynText_TextProp.setValue(xFactor);  // print single vals
            // } else {
            //   dynText_TextDocument.fontSize = Math.floor(dataSize[0] / 20);
            //   dynText_TextDocument.font = "RobotoMono-Medium";
            //   dynText_TextProp.setValue(dynText_TextDocument);
            //   dynText_TextProp.setValue('[' + a[0] + ', ' + a[1] + '] ››› [' + b[0] + ', ' + b[1] + ']');   // print arrays
            // }
          // }


            //// Transforms
            dynText.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([0, -dynText_TextDocument.fontSize*0.82, 0]);
            dynText.property("ADBE Transform Group").property("ADBE Position").setValue([textLeftEdge, stackPos, 0]);

          } catch(e) {
            alert(e.toString() + "\nError on line: " + e.line.toString());
          }

          //// update positioning variables
          stackPos += Math.round(icon.sourceRectAtTime(0, false).height) * (iconScale/100) + margin;

          Math.degrees = function(radians) {
            return radians * 180 / Math.PI;
          };

      }
      function valGeneric(activeProp) {
        var textBoxHeight = 100;

        var a = activeProp.startValue;
        var b = activeProp.endValue;
        try {
          //// draw icon
          var rotDir = ( true ) ? 1 : -1;
          var icon = thisComp.layers.addShape();
        		icon.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
        		icon.property("ADBE Root Vectors Group").property(1).name = "Rectangle 2";
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Group");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property("ADBE Vector Shape Direction").setValue(2);
        		var iconPath = icon.property("ADBE Root Vectors Group").property(1).property(2).property(1).property("ADBE Vector Shape");
        		var iconPath_shapeVertices = [[23.5,-24],[23.5,-20.75],[6.09375,-0.09375],[23.5,19.484375],[23.5,23.484375],[1.52951049804688,23.484375],[1.52951049804688,-24]];
        		var iconPath_shapeInTangets = [[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0]];
        		var iconPath_shapeOutTangets = [[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0]];
        		var iconPath_shapeClosed = true;
        		createStaticShape(iconPath, iconPath_shapeVertices, iconPath_shapeInTangets, iconPath_shapeOutTangets, iconPath_shapeClosed);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Graphic - Stroke");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(2).property("ADBE Vector Stroke Width").setValue(3);
        		icon.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Graphic - Fill");
        		icon.property("ADBE Root Vectors Group").property(1).property(2).property(3).property("ADBE Vector Fill Color").setValue([1,1,1,1]);
        		icon.property("ADBE Root Vectors Group").property(1).property(3).property("ADBE Vector Scale").setValue([-100,100]);
        		icon.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
        		icon.property("ADBE Root Vectors Group").property(2).name = "Rectangle 1";
        		icon.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Shape - Group");
        		icon.property("ADBE Root Vectors Group").property(2).property(2).property(1).property("ADBE Vector Shape Direction").setValue(2);
        		var iconPath = icon.property("ADBE Root Vectors Group").property(2).property(2).property(1).property("ADBE Vector Shape");
        		var iconPath_shapeVertices = [[23.5,-24],[23.5,-20.75],[6.09375,-0.09375],[23.5,19.484375],[23.5,23.484375],[1.52951049804688,23.484375],[1.52951049804688,-24]];
        		var iconPath_shapeInTangets = [[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0]];
        		var iconPath_shapeOutTangets = [[0,0],[0,0],[0,0],[0,0],[0,0],[0,0],[0,0]];
        		var iconPath_shapeClosed = true;
        		createStaticShape(iconPath, iconPath_shapeVertices, iconPath_shapeInTangets, iconPath_shapeOutTangets, iconPath_shapeClosed);
        		icon.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Graphic - Stroke");
        		icon.property("ADBE Root Vectors Group").property(2).property(2).property(2).property("ADBE Vector Stroke Width").setValue(3);
        		icon.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Graphic - Fill");
        		icon.property("ADBE Root Vectors Group").property(2).property(2).property(3).property("ADBE Vector Fill Color").setValue([1,1,1,1]);
        		icon.property("ADBE Root Vectors Group").property(2).property(2).property(3).property("ADBE Vector Fill Opacity").setValue(70);
        		icon.property("ADBE Transform Group").property("ADBE Scale").setValue([100,100,100]);



            //// Transforms
            icon.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([-25, -25, 0]);
            icon.property("ADBE Transform Group").property("ADBE Position").setValue([leftEdge, stackPos, 0]);
            icon.property("ADBE Transform Group").property("ADBE Scale").setValue([iconScale, iconScale]);


          //// update left edge
          var textLeftEdge = leftEdge + Math.round(icon.sourceRectAtTime(0, false).width) * (iconScale/100) + margin/2;


        //// draw text
        // var dynText = thisComp.layers.addText("Rotataion");
        var dynText = thisComp.layers.addBoxText([dataSize[0], textBoxHeight], 'Generic');     // gets value from edittext
            dynText.comment = scriptName + '_data';
            dynText.label = labelColor;
        var dynText_TextProp = dynText.property("ADBE Text Properties").property("ADBE Text Document");
        var dynText_TextDocument = dynText_TextProp.value;
          dynText_TextDocument.font = "RobotoMono-Regular";
          dynText_TextDocument.fontSize = Math.floor(dataSize[0] / 15);
          dynText_TextDocument.applyFill = true;
          dynText_TextDocument.fillColor = [1,1,1];
          dynText_TextDocument.applyStroke = false;
          dynText_TextDocument.justification = ParagraphJustification.LEFT_JUSTIFY;
          dynText_TextDocument.tracking = -5;
          if (parseFloat(app.version) >= 13.2 ) {
            dynText_TextDocument.verticalScale = 1;
            dynText_TextDocument.horizontalScale = 1;
            dynText_TextDocument.baselineShift = 0;
            dynText_TextDocument.tsume = 0;
          }
          dynText_TextProp.setValue(dynText_TextDocument);
          dynText_TextProp.setValue(round(a, 4).toString() + ' ››› ' + round(b, 4).toString());

            //// Transforms
            dynText.property("ADBE Transform Group").property("ADBE Anchor Point").setValue( [ dataSize[0]/-2, textBoxHeight/-2 - 1, 0] );
            dynText.property("ADBE Transform Group").property("ADBE Position").setValue([textLeftEdge, stackPos, 0]);

          } catch(e) {
            alert(e.toString() + "\nError on line: " + e.line.toString());
          }

            //// update positioning variables
            stackPos += Math.round(icon.sourceRectAtTime(0, false).height) * (iconScale/100) + margin;

      }
      function buildNotes() {
        var textBoxHeight = dataSize[1] - stackPos;
        try {


        //// draw text
        // var dynText = thisComp.layers.addText("Rotataion");
        var dynText = thisComp.layers.addBoxText([dataSize[0], textBoxHeight], 'Notes');     // gets value from edittext
            dynText.comment = scriptName + '_data';
            dynText.label = labelColor;
        var dynText_TextProp = dynText.property("ADBE Text Properties").property("ADBE Text Document");
        var dynText_TextDocument = dynText_TextProp.value;
          dynText_TextDocument.font = "RobotoMono-Regular";
          dynText_TextDocument.fontSize = Math.floor(dataSize[0] / 15);
          dynText_TextDocument.applyFill = true;
          dynText_TextDocument.fillColor = [1,1,1];
          dynText_TextDocument.applyStroke = false;
          dynText_TextDocument.justification = ParagraphJustification.LEFT_JUSTIFY;
          dynText_TextDocument.tracking = -5;
          if (parseFloat(app.version) >= 13.2 ) {
            dynText_TextDocument.verticalScale = 1;
            dynText_TextDocument.horizontalScale = 1;
            dynText_TextDocument.baselineShift = 0;
            dynText_TextDocument.tsume = 0;
          }
          dynText_TextProp.setValue(dynText_TextDocument);
          dynText_TextProp.setValue('Notes');

            //// Transforms
            dynText.property("ADBE Transform Group").property("ADBE Anchor Point").setValue( [ dataSize[0]/-2, textBoxHeight/-2 - 1, 0] );
            dynText.property("ADBE Transform Group").property("ADBE Position").setValue([leftEdge, stackPos, 0]);

          } catch(e) {
            alert(e.toString() + "\nError on line: " + e.line.toString());
          }

            //// update positioning variables
            // stackPos += Math.round(icon.sourceRectAtTime(0, false).height) * (iconScale/100) + margin;

      }
      function getValChange(activeProp) {
        switch (activeProp.obj.matchName) {
          case 'ADBE Scale':
            valScale(activeProp);
            break;
          case 'ADBE Position':
            valPosition(activeProp);
            break;
          case 'ADBE Rotate Z':
            valRotation(activeProp);
            break;
            case 'ADBE Opacity':
              valOpacity(activeProp);
              break;
          default:
            valGeneric(activeProp);
        }
        // if (activeProp.matchName === 'ADBE Opacity') {buildTxtHeader(activeProp);}
      }
      function getInterpolation(activeProp) {
        try {
          //// draw icon
          var iconCurve = thisComp.layers.addShape();
        		iconCurve.name = "Icon_Curve";
            iconCurve.label = labelColor;
            iconCurve.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
        		iconCurve.property("ADBE Root Vectors Group").property(1).name = "Rectangle 1";
        		iconCurve.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Rect");
        		iconCurve.property("ADBE Root Vectors Group").property(1).property(2).property(1).property("ADBE Vector Rect Size").setValue([42,42]);
        		iconCurve.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Filter - Trim");
        		iconCurve.property("ADBE Root Vectors Group").property(1).property(2).property(2).property("ADBE Vector Trim Start").setValue(27.6);
        		iconCurve.property("ADBE Root Vectors Group").property(1).property(2).property(2).property("ADBE Vector Trim End").setValue(50);
        		iconCurve.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Rect");
        		iconCurve.property("ADBE Root Vectors Group").property(1).property(2).property(3).property("ADBE Vector Rect Size").setValue([3,3]);
        		iconCurve.property("ADBE Root Vectors Group").property(1).property(2).property(3).property("ADBE Vector Rect Position").setValue([17.5,20.5]);
        		iconCurve.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Graphic - Stroke");
        		iconCurve.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Graphic - Fill");
        		iconCurve.property("ADBE Root Vectors Group").property(1).property(2).property(5).enabled = false;
        		iconCurve.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Filter - Repeater");
        		iconCurve.property("ADBE Root Vectors Group").property(1).property(2).property(6).property("ADBE Vector Repeater Copies").setValue(2);
        		iconCurve.property("ADBE Root Vectors Group").property(1).property(2).property(6).property(4).property("ADBE Vector Repeater Rotation").setValue(180);
        		iconCurve.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
        		iconCurve.property("ADBE Root Vectors Group").property(2).name = "Curve";
        		iconCurve.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Shape - Group");
        		iconCurve.property("ADBE Root Vectors Group").property(2).property(2).property(1).property("ADBE Vector Shape Direction").setValue(2);
        		var iconCurvePath = iconCurve.property("ADBE Root Vectors Group").property(2).property(2).property(1).property("ADBE Vector Shape");
        		var iconCurvePath_shapeVertices = [[-25.0000152587891,20.671875],[25.0000610351562,-20.109375]];
        		var iconCurvePath_shapeInTangets = [[-36.375,0],[-36.5000610351562,0]];
        		var iconCurvePath_shapeOutTangets = [[36.3750152587891,0],[32.1249694824219,0]];
        		var iconCurvePath_shapeClosed = false;
        		createStaticShape(iconCurvePath, iconCurvePath_shapeVertices, iconCurvePath_shapeInTangets, iconCurvePath_shapeOutTangets, iconCurvePath_shapeClosed);
        		iconCurve.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Graphic - Stroke");
        		iconCurve.property("ADBE Root Vectors Group").property(2).property(2).property(2).property("ADBE Vector Stroke Width").setValue(8);
        		iconCurve.property("ADBE Root Vectors Group").property(2).property(2).addProperty("ADBE Vector Graphic - G-Fill");
        		iconCurve.property("ADBE Root Vectors Group").property(2).property(2).property(3).enabled = false;

            //// Transforms
            iconCurve.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([-25, -25, 0]);
            iconCurve.property("ADBE Transform Group").property("ADBE Position").setValue([leftEdge, stackPos, 0]);
            iconCurve.property("ADBE Transform Group").property("ADBE Scale").setValue([iconScale, iconScale]);


        //// update left edge
        var textLeftEdge = leftEdge + Math.round(iconCurve.sourceRectAtTime(0, false).width) * (iconScale/100) + margin/2;


        //// draw text
        var dynText = thisComp.layers.addText("Duration");
            dynText.comment = scriptName + '_data';
            dynText.label = labelColor;
        var dynText_TextProp = dynText.property("ADBE Text Properties").property("ADBE Text Document");
        var dynText_TextDocument = dynText_TextProp.value;
          dynText_TextDocument.font = "RobotoMono-Medium";
          dynText_TextDocument.fontSize = Math.floor(dataSize[0] / 20);
          dynText_TextDocument.applyFill = true;
          dynText_TextDocument.fillColor = [1,1,1];
          dynText_TextDocument.applyStroke = false;
          dynText_TextDocument.justification = ParagraphJustification.LEFT_JUSTIFY;
          dynText_TextDocument.tracking = -5;
          if (parseFloat(app.version) >= 13.2 ) {
            dynText_TextDocument.verticalScale = 1;
            dynText_TextDocument.horizontalScale = 1;
            dynText_TextDocument.baselineShift = 0;
            dynText_TextDocument.tsume = 0;
          }
          dynText_TextProp.setValue(dynText_TextDocument);
          dynText_TextProp.setValue(curveVal(activeProp));
          // alert(speedInfluenceToXy(activeProp));

            //// Transforms
            dynText.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([0, -dynText_TextDocument.fontSize, 0]);
            dynText.property("ADBE Transform Group").property("ADBE Position").setValue([textLeftEdge, stackPos, 0]);

          } catch(e) {
            alert(e.toString() + "\nError on line: " + e.line.toString());
          }

          //// update positioning variables
          stackPos += Math.round(iconCurve.sourceRectAtTime(0, false).height) * (iconScale/100) + margin;
      }
      function curveVal(activeProp) {
        var dims = (activeProp.obj.value instanceof Array) ? activeProp.obj.value.length : 1;
        var k1 = activeProp.startValue;
        var k2 = activeProp.endValue;

        // activeProp = activeProp.obj;

        var change = (dims == 1 || activeProp.propertyType == 5612) ? k2 - k1 : Math.sqrt( Math.pow(k2[0] - k1[0], 2) + Math.pow(k2[1] - k1[1], 2) );
        var keyOutSp = (activeProp.startTemporalEase.speed < 0) ? activeProp.startTemporalEase.speed : -activeProp.startTemporalEase.speed;
        var y1Mult = (activeProp.startTemporalEase.speed < 0) ? 1 : -1;
        var keyInSp = (activeProp.endTemporalEase.speed < 0) ? activeProp.endTemporalEase.speed : -activeProp.endTemporalEase.speed;
        var y2Mult = (activeProp.endTemporalEase.speed < 0) ? 1 : -1;
        var y2Sub = (dims > 1 && activeProp.endTemporalEase.speed > 0) ? -1 : 1;

        // alert(activeProp.name + ' :: ' + y2Sub);

        var x1 = activeProp.startTemporalEase.influence/100;
        var y1 = ((keyOutSp * x1) * activeProp.duration/change) * y1Mult;
        var x2 = 1 - activeProp.endTemporalEase.influence/100;
        var y2 = y2Sub - ((keyInSp * (x2-1)) * activeProp.duration/change) * y2Mult;


        //// check type of keys
        if (activeProp.startEaseType == KeyframeInterpolationType.LINEAR && activeProp.endEaseType == KeyframeInterpolationType.LINEAR) {
          return 'Linear';
        } else if (isNaN(y1)){
          return 'No Change';
        } else {
          return '(' + round(x1) + ', ' + round(y1) + ', ' + round(x2) + ', ' + round(y2) + ')';
        }
      }
      function isolationMode(selectedLayers) {
        var lowestLayerIndex = 1;
        //
        for (var i = 0; i < selectedLayers.length; i++) {
          lowestLayerIndex = Math.max(lowestLayerIndex, selectedLayers[i].index);
        }

        if (lowestLayerIndex === thisComp.numLayers-1){ return;}
        lowestLayerIndex += 2;

        var isolationLayer = thisComp.layers.addShape();
            isolationLayer.name = 'Isolation';
            isolationLayer.label = 0;
            isolationLayer.adjustmentLayer = true;
            thisComp.layer(1).moveAfter(thisComp.layer(lowestLayerIndex));
            isolationLayer.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
        		isolationLayer.property("ADBE Root Vectors Group").property(1).name = "Rectangle 1";
        		isolationLayer.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Shape - Rect");
        		isolationLayer.property("ADBE Root Vectors Group").property(1).property(2).property(1).property("ADBE Vector Rect Size").setValue([thisComp.width, thisComp.height]);
        		isolationLayer.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Graphic - Stroke");
        		isolationLayer.property("ADBE Root Vectors Group").property(1).property(2).property(2).enabled = false;
        		isolationLayer.property("ADBE Root Vectors Group").property(1).property(2).property(2).property("ADBE Vector Stroke Width").setValue(3);
        		isolationLayer.property("ADBE Root Vectors Group").property(1).property(2).addProperty("ADBE Vector Graphic - Fill");
        		isolationLayer.property("ADBE Root Vectors Group").property(1).property(2).property(3).property("ADBE Vector Fill Color").setValue([0,0,0,1]);
        		isolationLayer.property("ADBE Effect Parade").addProperty("ADBE Tint");
        		isolationLayer.property("ADBE Effect Parade").property(1).property("ADBE Tint-0001").setValue([0.3,0.3,0.3,1]);
        		isolationLayer.property("ADBE Effect Parade").property(1).property("ADBE Tint-0002").setValue([0.35,0.35,0.35,1]);


      }
      function launchSettings() {   // open an additional window
        var win = new Window('dialog', scriptName, undefined, {resizeable:false});

        //stop if there's no window
        if (win === null) return;

        // set margins and alignment
        win.alignChildren = ['fill','fill'];
        win.minimumSize.width = 350;
        win.margins = 5;
        win.spacing = 2;

        {   // ============ ADD UI CONTENT HERE =================
          var content = win.add('group');
              content.orientation = 'column';
              content.alignChildren = 'fill';
              content.margins = 20;
              content.spacing = 2;
              var writeUp = content.add('statictext',undefined, aboutTxt, {multiline: true});
                  // writeUp.alignment = 'fill';


          var dialogButtons = win.add('group');
              dialogButtons.alignChildren = ['fill','fill'];
              dialogButtons.orientation = 'row';
              dialogButtons.minimumSize.height = 40;
              dialogButtons.margins = 0;
              dialogButtons.spacing = 4;
              // dialogButtons.add('button',undefined,'OK');
              var url = dialogButtons.add('button', undefined, 'go/inspectorSpacetime')
              dialogButtons.add('button',undefined,'Close',{name:'ok'});
        }
        url.onClick = function () {
          visitURL('http://go/inspectorspacetime');
        };

        {
          // Set layout, and resize it on resize of the Panel/Window
          win.layout.layout(true);
          win.layout.resize();
          win.onResizing = win.onResize = function () {win.layout.resize();};
          //if the script is not a Panel (launched from File/Scripts/Run script...) we need to show it
          if (!(win instanceof Panel)) win.show();
        }
      }
      function visitURL(url) {    // create clickable links
          if ($.os.indexOf("Windows") != -1) {
              system.callSystem('cmd /c "' + Folder.commonFiles.parent.fsName + "\\Internet Explorer\\iexplore.exe" + '" ' + url);
          } else {
              var cmd = 'open "' + url + '"';
              system.callSystem(cmd);
          }
      }


    // _______ UI SETUP _______
      // if the script is a Panel, (launched from the 'Window' menu), use it,
      // else (launched via 'File/Scripts/Run script...') create a new window
      // store it in the variable mainPalette
      var mainPalette = thisObj instanceof Panel ? thisObj : new Window('palette',scriptName,undefined, {resizeable:true});

      //stop if there's no window
      if (mainPalette === null) return;

      // set margins and alignment
      mainPalette.alignChildren = ['fill','fill'];
      mainPalette.margins = 2;
      mainPalette.spacing = 2;
    //__________________________


        // ============ UI VARIABLES ====================
        var defaultHeaderName = 'Element name...';

         // ============ ADD UI CONTENT HERE =================
        var content = mainPalette.add('group');
        content.alignChildren = ['fill','fill'];
        content.orientation = 'column';
        content.margins = 0;
        content.spacing = 10;

        // var btnLayer = [];
        // btnLayer.length = 7;
        //
        // for (var i = btnLayer.length; i > 0; i--) {
        //   btnLayer[i] = content.add('button', undefined, i);
        // }

        //// prep Section
        // var grp_prep = content.add('panel', undefined, 'Prep');
            // grp_prep.orientation = 'row';
            // grp_prep.alignChildren = ['fill','fill'];
        // var btn_AddPanel = content.add('button', undefined, 'New Spec Panel');
        // var btn_transStart = content.add('button', undefined, 'Set Transition Start');

        // var theText = content.add('statictext',undefined,'This is a script called: ' + scriptName);
        // var btnGrabInfo = content.add('button',undefined,'Grab info');
        // var et_name = content.add('edittext', undefined, defaultHeaderName);
        //     et_name.addEventListener('focus', clearInput);
        //     et_name.addEventListener('blur', defaultInput);

        // //// keyframe timing group
        // var grp_Time = content.add('group');
        //     grp_Time.orientation = 'row';
        //     grp_Time.alignChildren = ['fill','fill'];
        //     var btn_getStart = grp_Time.add('button', undefined, '\xb1');
        //         btn_getStart.preferredSize.width = 30;
        //     var et_startTime = grp_Time.add('edittext', undefined, timeVal[0], {readonly: true});
        //     var ddl_timing = grp_Time.add('dropdownlist', undefined, ['Milliseconds', 'Seconds', 'Frames']);
        //         ddl_timing.selection = 0;
        //     var et_endTime = grp_Time.add('edittext', undefined, timeVal[1], {readonly: true});
        //     var btn_getEnd = grp_Time.add('button', undefined, '\xb1');
        //         btn_getEnd.preferredSize.width = 30;

        //// keyframe velocity


        //// Header
        // var header = content.add('group');
        //   header.maximumSize.height = 30;
        //   header.minimumSize.height = 15;
        //   // header.graphics.backgroundColor = header.graphics.newBrush (header.graphics.BrushType.SOLID_COLOR, [0.2157, 0.2784, 0.3098]);
        //
        //   // var headerTxt = header.add('statictext',undefined, scriptName + ' v' + scriptVersion);
        //   var headerTxt = header.add('button',undefined, scriptName + ' v' + scriptVersion + '  \u2192');
        //       headerTxt.graphics.foregroundColor = headerTxt.graphics.newPen (headerTxt.graphics.PenType.SOLID_COLOR, [0.9, 0.9, 0.9], 1);
        //       headerTxt.alignment = ['fill', 'fill'];

        var btnLaunch = content.add('button',undefined,'Build Keyframe Specs');
            btnLaunch.maximumSize.height = 60;
            btnLaunch.minimumSize.height = 40;

        var grp_options = content.add('group');
          grp_options.orientation = 'row';
          grp_options.alignChildren = ['fill', 'fill'];
          grp_options.margins = 0;

        var spec = grp_options.add('panel', undefined, 'Specs');
            spec.alignChildren = ['fill', 'top'];
            spec.minimumSize.height = 150;
          var pref_total = spec.add('checkbox', undefined, 'Total Duration');
              pref_total.value = true;
          var pref_name = spec.add('checkbox', undefined, 'Property Name');
              pref_name.value = true;
          // var pref_offset = spec.add('checkbox', undefined, 'Offset');
          //     pref_offset.value = true;
          // var pref_duration = spec.add('checkbox', undefined, 'Duration');
          //     pref_duration.value = true;
          var pref_curve = spec.add('checkbox', undefined, 'Easing');
              pref_curve.value = true;
          var pref_valChange = spec.add('checkbox', undefined, 'Value Change');
              pref_valChange.value = true;
          var pref_notes = spec.add('checkbox', undefined, 'Notes');

        var settings = grp_options.add('group');
            settings.minimumSize.height = 150;
            settings.alignChildren = ['fill', 'top'];
            settings.orientation = 'column';
            settings.margins = [2, 8, 2, 2];
            var rad_pos = settings.add('panel', undefined, 'Position');
                rad_pos.alignChildren = 'left';
                rad_pos.orientation = 'column';
                rad_pos.spacing = 2;
                rad_pos.margins = [2, 8, 2, 2];
                rad_pos.add('radiobutton', undefined, 'Coordinates');
                rad_pos.add('radiobutton', undefined, 'Distance');
                rad_pos.children[0].value = true;
            // var rad_scale = settings.add('panel', undefined, 'Scale');
            //     rad_scale.alignChildren = 'left';
            //     rad_scale.orientation = 'column';
            //     rad_scale.spacing = 2;
            //     rad_scale.margins = [2, 8, 2, 2];
            //     rad_scale.add('radiobutton', undefined, 'Factor');
            //     rad_scale.add('radiobutton', undefined, 'Percentage');
            //     rad_scale.children[0].value = true;
              var ddl_resolution = settings.add('dropdownlist', undefined, ['1x', '2x', '3x']);
                  ddl_resolution.selection = 2;
            var pref_isolation = settings.add('checkbox', undefined, 'Isolation Mode');
                pref_isolation.value = true;
            var btn_help = settings.add('button', undefined, '?');
                btn_help.minimumSize = [30, 30];
                btn_help.maximumSize = [30, 30];
                btn_help.padding = 10;
                btn_help.alignment = ['right', 'bottom'];



        // var btnURL = content.add('button',undefined,'Visit website');

        // ============ Button Functionality =================
        // header name edittext functions
        function clearInput() {
          if (et_name.text === defaultHeaderName ) {
              et_name.text = '';
          }
        }
        function defaultInput() {
          if (et_name.text === '') {
              et_name.text = defaultHeaderName;
          }
        }

        // btn_transStart.onClick = function() {
        //   setComp();
        //   setStartPoint();
        // }

        // btn_AddPanel.onClick = function() {
        //   app.beginUndoGroup('Create ' + scriptName + 'Panel');
        //   if ( setComp() ) {    // if no comp is selected then dont run the rest of this
        //     if (et_name.text === defaultHeaderName) { et_name.text = 'Element 1';}   // rename element if default value is unchanged
        //     // elementName = nameInc(et_name.text);      // get the element name from edittext
        //     createISTfolder();
        //     resizeComp(thisComp, et_name.text);
        //     setStartPoint();
        //
        //   }
        //   app.endUndoGroup();
        // };
        // ddl_timing.onChange = function() {
        //   et_startTime.text = timeConvert(timeVal[0]);
        //   et_endTime.text = timeConvert(timeVal[1]);
        // }
        // btn_getStart.onClick = function() {
        //   setComp();
        //   timeVal[0] = getPlayheadTime();
        //   et_startTime.text = timeConvert( getPlayheadTime() );
        // }
        // btn_getEnd.onClick = function() {
        //   timeVal[1] = getPlayheadTime();
        //   et_endTime.text = timeConvert( getPlayheadTime() );
        // }
        // btnGrabInfo.onClick = function() {
        //   grabCompData();
        // }

        // headerTxt.onClick = function () {
        //   visitURL('http://go/inspectorspacetime');
        // };

        btn_help.onClick = function() {
          launchSettings();
        }

        btnLaunch.onClick = function() {
          var selectedProperties = [], propCollect = [], totalDuration, firstKeyTime = 0, lastKeyTime = 0;

          //// Labels
          labelColor = 3;
          var labelSign = -1;

          app.beginUndoGroup('Create ' + scriptName + 'Elements');

          if (!setComp()) {return; }     // if no comp selected return

          var selectedLayers = thisComp.selectedLayers;

          //// Add properties from all selected layers
          try {                         // if no keys selected return
            for (var i = 0; i < selectedLayers.length; i++) {
              for (var j = 0; j < selectedLayers[i].selectedProperties.length; j++) {
                selectedProperties.push(selectedLayers[i].selectedProperties[j]);
              }
            }
          } catch (e) {
            alert('Select some keyframes dude.');
            return;
          }

          // if (selectedProperties.length === 0) {alert('Select some keyframes dude.')};
          resizeComp(thisComp);
          getPanelSize();


          //// get the props as an array of objects
          for (var k = 0; k < selectedProperties.length; k++) {
            if (selectedProperties[k].canVaryOverTime && selectedProperties[k].selectedKeys.length > 1) {   // check if selected prop is keyframable
              var selKeys = selectedProperties[k].selectedKeys;
              propCollect.push( {
                obj: selectedProperties[k],
                startIndex: selKeys[0],
                startTime: selectedProperties[k].keyTime(selKeys[0]),
                startValue: selectedProperties[k].keyValue(selKeys[0]),
                startTemporalEase: selectedProperties[k].keyOutTemporalEase(selKeys[0])[0],
                startEaseType: selectedProperties[k].keyOutInterpolationType(selKeys[0]),
                endIndex: selKeys[1],
                endTime: selectedProperties[k].keyTime(selKeys[1]),
                endValue: selectedProperties[k].keyValue(selKeys[1]),
                endTemporalEase: selectedProperties[k].keyInTemporalEase(selKeys[1])[0],
                endEaseType: selectedProperties[k].keyInInterpolationType(selKeys[1]),
                duration: selectedProperties[k].keyTime(selKeys[1]) - selectedProperties[k].keyTime(selKeys[0])
              } );
              lastKeyTime = Math.max(lastKeyTime, propCollect[propCollect.length-1].endTime);
            }
          }


          //// sort the props by start time
          propCollect.sort(function (a, b) {
            if (a.startTime > b.startTime) {
              return 1;
            }
            if (a.startTime < b.startTime) {
              return -1;
            }
            return 0;
          });

          firstKeyTime = propCollect[0].startTime;

          //// Calc the total duration
          totalDuration = lastKeyTime - propCollect[0].startTime;

          // run isolationMode
          (pref_isolation.value) ? isolationMode(selectedLayers) : null;

          //// create property data
          (pref_total.value) ? builtTRT(totalDuration) : null;
          //// individual properties
          for (var j = 0; j < propCollect.length; j++) {
            (pref_name.value) ? buildTxtHeader(propCollect[j]) : null;      // header
            valTiming(propCollect[j], firstKeyTime);    // timing
            (pref_valChange.value) ? getValChange(propCollect[j]) : null;
            (pref_curve.value) ? getInterpolation(propCollect[j]) : null;

            stackPos += margin;

            // alternate labels
            labelSign *= -1;
            labelColor += labelSign;
          }
          //// build notes field
          (pref_notes.value) ? buildNotes() : null;

          app.endUndoGroup();
        }
        //
        // btnURL.onClick = function() {
        //   visitURL('http://battleaxe.co');
        // };

    // ==================================================

    //__________ SHOW UI ___________
      {
        // Set layout, and resize it on resize of the Panel/Window
        mainPalette.layout.layout(true);
        mainPalette.layout.resize();
        mainPalette.onResizing = mainPalette.onResize = function () {mainPalette.layout.resize();};
        //if the script is not a Panel (launched from File/Scripts/Run script...) we need to show it
        if (!(mainPalette instanceof Panel)) mainPalette.show();
      }
    //______________________________

})(this);
